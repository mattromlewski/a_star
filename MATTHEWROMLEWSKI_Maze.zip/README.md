# Pathfinding Algorithms

## Requirements

Need Python 3.7 or older to support pygame.


```bash

pip install -r requirements.txt

```

RUN THE MAIN FILE

## Breadth First Search

## Depth First Search

## A*

